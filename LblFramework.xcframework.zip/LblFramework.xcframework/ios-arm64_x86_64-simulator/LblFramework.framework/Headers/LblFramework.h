//
//  LblFramework.h
//  LblFramework
//
//  Created by Kostadina Gecevska on 27.6.24.
//

#import <Foundation/Foundation.h>

//! Project version number for LblFramework.
FOUNDATION_EXPORT double LblFrameworkVersionNumber;

//! Project version string for LblFramework.
FOUNDATION_EXPORT const unsigned char LblFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LblFramework/PublicHeader.h>


